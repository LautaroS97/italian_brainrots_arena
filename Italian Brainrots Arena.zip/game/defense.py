from game.game_state import GameState
from game.battle import BattleManager
from game.battle_event import BattleEvent

def process_defense_event(event, battle_manager: BattleManager, game_state: GameState):
    actor = event.user
    defender = event.target
    skill = event.skill

    game_state.start_skill_animation(actor, skill)
    if getattr(skill, 'is_wall', False) and skill.freeze_frame is not None:
        game_state.pause_animation_at(actor, skill.freeze_frame)
    elif getattr(skill, 'sync_frame', None) is not None:
        game_state.mark_sync_frame(actor, skill.sync_frame)

    opp_event = battle_manager.next_event_for(defender)
    if opp_event:
        game_state.start_skill_animation(defender, opp_event.skill)
    if getattr(skill, 'is_wall', False) and skill.freeze_frame is not None:
        game_state.wait_until_animation_ends(defender)

    if getattr(skill, 'is_wall', False):
        battle_manager.apply_wall(defender)
    else:
        battle_manager.apply_damage_reduction(defender, getattr(skill, 'damage_reduction_factor', 1.0))

    battle_manager.emit_event(
        'log',
        message=(
            f"El ataque de {defender.name} se ve afectado por {skill.name}: "
            f"{'bloqueo total' if getattr(skill, 'is_wall', False) else f'reducción de {int(getattr(skill, 'damage_reduction_factor',0)*100)}%'}"
        )
    )

    battle_manager.emit_event('pp_spent', actor=actor, amount=getattr(skill, 'cost', 0))
    if opp_event:
        battle_manager.emit_event('pp_spent', actor=defender, amount=getattr(opp_event.skill, 'cost', 0))

    if getattr(skill, 'reflect_damage', 0) > 0 and opp_event:
        dmg = battle_manager.calculate_reflect(defender, skill.reflect_damage)
        battle_manager.apply_damage(defender, dmg)
        battle_manager.emit_event('damage_applied', target=defender, amount=dmg)

    if getattr(skill, 'is_wall', False) and skill.freeze_frame is not None:
        game_state.resume_animation(actor)